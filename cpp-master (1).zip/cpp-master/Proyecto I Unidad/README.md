# Descargue el codigo del Proyecto de la Unidad I

### 1) El objetivo es crear un menu en la funcion main para asi poder jugar el juego StarShip o Snake

El menu debe contener estas opciones:


```sh

**************
MENU DE JUEGOS
**************

Seleccione un juego

1 - StarShip

2 - Snake

Ingrese un numero del menu para seleccionar un juego:

```


### 2) Para poder compilar el programa ejecute el comando

`./compilar.bat`

### 3) Vea este video para mas detalle en esta asignacion

https://www.youtube.com/watch?v=hOGHh8dnbjg

### 4) Entregables

1) Link de github.com ***10%
2) Video Youtube demostrando la funcionalidad de su sistema y el codigo que implemento para el menu ***7%

