#include <iostream>

using namespace std;

extern void menu();

int main(int argc, char const *argv[])
{
    menu();
    
    return 0;
}
