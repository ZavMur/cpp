#include <iostream>

using namespace std;

int main(int argc, char const *argv[])
{
    int numeros[5]; // declaracion del arreglo

    // asignacion de valares a un arreglo unidimensional
    numeros[0] = 10;
    numeros[1] = 5;
    numeros[2] = 7;
    numeros[3] = 50;
    numeros[4] = 2;

    // lectura de los valores de un arreglo unidimensional
    cout << numeros[0] << endl;
    cout << numeros[1] << endl;
    cout << numeros[2] << endl;
    cout << numeros[3] << endl;
    cout << numeros[4] << endl;
    
    return 0;
}
