#include <iostream>

using namespace std;

int main(int argc, char const *argv[])
{
    string nombre;
    
    cout << "Ingrese su nombre: ";
    cin >> nombre;

    cout << endl;
    cout << "Hola mi nombre es " << nombre;
    cout << endl;
    
    return 0;
}

