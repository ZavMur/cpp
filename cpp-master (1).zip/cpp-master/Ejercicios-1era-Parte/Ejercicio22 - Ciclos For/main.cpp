#include <iostream>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

using namespace std;

int main(int argc, char** argv) {
	
	for (int indice = 1; indice <= 10; indice++)
 	{
 		cout << "Valor de la variable indice " << indice << endl;
	}	

	return 0;
}
