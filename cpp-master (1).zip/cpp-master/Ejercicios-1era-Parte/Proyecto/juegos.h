void mostrarJuegos();
string buscarJuego(string codigo);