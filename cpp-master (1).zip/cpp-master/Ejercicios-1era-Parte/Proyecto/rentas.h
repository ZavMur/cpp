void rentar();
void reporteRentas();