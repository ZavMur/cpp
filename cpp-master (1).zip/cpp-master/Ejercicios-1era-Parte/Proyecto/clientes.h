#include <iostream>

using namespace std;

void mostrarClientes();
string buscarCliente(string codigo);