#include <iostream>

using namespace std;

int main(int argc, char const *argv[])
{
    bool valorBoolean;
    valorBoolean = false;

    int valorEntero = 15;
    double valorDouble = 20.99;
    string valorString = "Hola como estan";
    char valorChar = 'B';
    
    cout << "Valor Boolean: " << valorBoolean << endl;
    cout << "Valor Entero: " << valorEntero << endl;
    cout << "Valor Double: " << valorDouble << endl;
    cout << "Valor String: " << valorString << endl;
    cout << "Valor Char: " << valorChar << endl;

    return 0;
}
