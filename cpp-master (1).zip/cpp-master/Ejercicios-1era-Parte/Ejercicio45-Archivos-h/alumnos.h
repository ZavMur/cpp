#include <iostream>

using namespace std;

string obtenerNombreCompleto();
int obtenerEdad();
