#include <iostream>

using namespace std;

int main(int argc, char const *argv[])
{
    for (int i = 1; i <= 10; i++)
    {
        cout << "indice: " << i;
        cout << endl;
    }

    cout << endl;
    cout << endl;

    int i = 1;

    while(i <= 10) {
        cout << "indice: " << i;
        cout << endl;
        i++;
    }
    
    return 0;
}
