#include <iostream>

using namespace std;

int main(int argc, char const *argv[])
{
    int numeroEntero;
    numeroEntero = 15;

    cout << "Entero: " << numeroEntero << endl;

    numeroEntero = 18;

    cout << "Entero modificado: " << numeroEntero;

    return 0;
}
