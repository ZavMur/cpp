#include <stdio.h>
#include "dino.h"

int main()
{
  return jugar();
}

