int jugar();
